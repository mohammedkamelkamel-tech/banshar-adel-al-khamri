package com.adel.banshar

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.telephony.SmsManager
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class CustomerActivity : AppCompatActivity() {
    private lateinit var db: Db
    private var customerId = 0L
    private var existing: Customer? = null
    private lateinit var name: EditText
    private lateinit var phone: EditText
    private lateinit var vehicle: EditText
    private lateinit var oilType: EditText
    private lateinit var type: Spinner
    private lateinit var oilPrice: EditText
    private lateinit var servicePrice: EditText
    private lateinit var paid: EditText
    private lateinit var days: EditText
    private lateinit var total: TextView
    private lateinit var remaining: TextView

    private val types = arrayOf("تغيير زيت فقط", "زيت وسرويس", "سرويس فقط")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_customer)
        db = Db(this)
        bindViews()
        type.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, types)
        type.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { recalc() }
        }
        listPriceFields().forEach { it.setOnFocusChangeListener { _, _ -> recalc() } }
        listPriceFields().forEach { it.addTextChangedListener(SimpleTextWatcher { recalc() }) }

        customerId = intent.getLongExtra("id", 0L)
        if (customerId > 0) {
            existing = db.all().firstOrNull { it.id == customerId }
            existing?.let { fill(it) }
            findViewById<Button>(R.id.save).visibility = View.GONE
            findViewById<Button>(R.id.payDue).visibility = View.VISIBLE
            findViewById<Button>(R.id.sms).visibility = View.VISIBLE
            findViewById<Button>(R.id.whatsapp).visibility = View.VISIBLE
            findViewById<Button>(R.id.payDue).setOnClickListener { payDue() }
            findViewById<Button>(R.id.sms).setOnClickListener { sendSms() }
            findViewById<Button>(R.id.whatsapp).setOnClickListener { whatsapp() }
        } else {
            days.setText("30")
        }
        findViewById<Button>(R.id.save).setOnClickListener { save() }
        recalc()
    }

    private fun bindViews() {
        name=findViewById(R.id.name); phone=findViewById(R.id.phone); vehicle=findViewById(R.id.vehicle); oilType=findViewById(R.id.oilType)
        type=findViewById(R.id.serviceType); oilPrice=findViewById(R.id.oilPrice); servicePrice=findViewById(R.id.servicePrice)
        paid=findViewById(R.id.paid); days=findViewById(R.id.days); total=findViewById(R.id.total); remaining=findViewById(R.id.remaining)
    }
    private fun listPriceFields() = listOf(oilPrice, servicePrice, paid)
    private fun d(e: EditText) = e.text.toString().toDoubleOrNull() ?: 0.0
    private fun recalc() {
        val t = when (type.selectedItem?.toString()) {
            "تغيير زيت فقط" -> d(oilPrice)
            "زيت وسرويس" -> d(oilPrice) + d(servicePrice)
            "سرويس فقط" -> d(servicePrice)
            else -> 0.0
        }
        val r = maxOf(t - d(paid), 0.0)
        total.text = "الإجمالي: ${money(t)} ريال"
        remaining.text = "المتبقي: ${money(r)} ريال"
    }
    private fun save() {
        if (name.text.toString().trim().isEmpty()) { name.error = "اكتب اسم العميل"; return }
        val t = when (type.selectedItem.toString()) {
            "تغيير زيت فقط" -> d(oilPrice)
            "زيت وسرويس" -> d(oilPrice)+d(servicePrice)
            else -> d(servicePrice)
        }
        val p = d(paid)
        val r = maxOf(t-p,0.0)
        val daysValue = days.text.toString().toIntOrNull() ?: 30
        val last = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, daysValue) }
        val next = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
        db.insert(Customer(name=name.text.toString().trim(), phone=phone.text.toString().trim(), vehicle=vehicle.text.toString().trim(), oilType=oilType.text.toString().trim(), serviceType=type.selectedItem.toString(), oilPrice=d(oilPrice), servicePrice=d(servicePrice), paid=p, remaining=r, days=daysValue, lastDate=last, nextDate=next))
        Toast.makeText(this, if (r>0) "تم الحفظ وتسجيل المتبقي كدين" else "تم الحفظ", Toast.LENGTH_LONG).show()
        finish()
    }
    private fun payDue() {
        val c = existing ?: return
        if (c.remaining <= 0) { Toast.makeText(this,"لا يوجد مبلغ متبقي",Toast.LENGTH_SHORT).show(); return }
        val input = EditText(this).apply { hint="مبلغ السداد"; inputType=2 or 8192 }
        AlertDialog.Builder(this).setTitle("تسجيل سداد").setView(input).setPositiveButton("حفظ") { _, _ ->
            val amount=input.text.toString().toDoubleOrNull() ?: 0.0
            val newPaid=c.paid+amount
            val newRemaining=maxOf(c.total()-newPaid,0.0)
            db.updatePayment(c.id,newPaid,newRemaining)
            Toast.makeText(this,"تم تحديث المتبقي",Toast.LENGTH_SHORT).show(); finish()
        }.setNegativeButton("إلغاء",null).show()
    }
    private fun sendSms() {
        val number=phone.text.toString().trim(); if(number.isEmpty()) return
        val msg="عميلنا العزيز ${name.text}: إجمالي الخدمة ${money(existing?.total() ?: 0.0)} ريال، المتبقي ${money(existing?.remaining ?: 0.0)} ريال."
        startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).putExtra("sms_body",msg))
    }
    private fun whatsapp() {
        val number=phone.text.toString().replace("+","").replace(" ",""); if(number.isEmpty()) return
        val msg=Uri.encode("مرحباً ${name.text}، إجمالي الخدمة ${money(existing?.total() ?: 0.0)} ريال، المتبقي ${money(existing?.remaining ?: 0.0)} ريال.")
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$number?text=$msg"))) } catch (_: Exception) { Toast.makeText(this,"واتساب غير مثبت",Toast.LENGTH_SHORT).show() }
    }
    private fun fill(c: Customer) {
        name.setText(c.name); phone.setText(c.phone); vehicle.setText(c.vehicle); oilType.setText(c.oilType); oilPrice.setText(c.oilPrice.toString()); servicePrice.setText(c.servicePrice.toString()); paid.setText(c.paid.toString()); days.setText(c.days.toString()); type.setSelection(types.indexOf(c.serviceType).coerceAtLeast(0)); recalc()
    }
    private fun money(x: Double)=String.format(Locale.US,"%.0f",x)
    private class SimpleTextWatcher(val f:()->Unit): android.text.TextWatcher { override fun beforeTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){}; override fun onTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){f()}; override fun afterTextChanged(s:android.text.Editable?){} }
}
