package com.adel.banshar

data class Customer(
    val id: Long = 0,
    val name: String,
    val phone: String,
    val vehicle: String,
    val oilType: String,
    val serviceType: String,
    val oilPrice: Double,
    val servicePrice: Double,
    val paid: Double,
    val remaining: Double,
    val days: Int,
    val lastDate: String,
    val nextDate: String
) {
    fun total(): Double = when (serviceType) {
        "تغيير زيت فقط" -> oilPrice
        "زيت وسرويس" -> oilPrice + servicePrice
        "سرويس فقط" -> servicePrice
        else -> oilPrice + servicePrice
    }
}
