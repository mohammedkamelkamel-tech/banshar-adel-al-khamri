package com.adel.banshar

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class Db(context: Context) : SQLiteOpenHelper(context, "banshar.db", null, 3) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE customers (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,vehicle TEXT,oilType TEXT,serviceType TEXT NOT NULL,oilPrice REAL DEFAULT 0,servicePrice REAL DEFAULT 0,paid REAL DEFAULT 0,remaining REAL DEFAULT 0,days INTEGER DEFAULT 30,lastDate TEXT,nextDate TEXT)""")
        createInventoryTables(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) createInventoryTables(db)
        if (oldVersion >= 2 && oldVersion < 3) {
            db.execSQL("ALTER TABLE products ADD COLUMN barcode TEXT DEFAULT ''")
        }
    }

    private fun createInventoryTables(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,category TEXT,unit TEXT DEFAULT 'علبة',barcode TEXT DEFAULT '',quantity REAL DEFAULT 0,purchasePrice REAL DEFAULT 0,salePrice REAL DEFAULT 0,minStock REAL DEFAULT 0,createdAt TEXT NOT NULL)""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS sales (id INTEGER PRIMARY KEY AUTOINCREMENT,productId INTEGER NOT NULL,quantity REAL NOT NULL,unitPrice REAL NOT NULL,total REAL NOT NULL,soldAt TEXT NOT NULL)""")
    }

    fun insert(c: Customer): Long {
        val v = ContentValues().apply {
            put("name", c.name); put("phone", c.phone); put("vehicle", c.vehicle); put("oilType", c.oilType)
            put("serviceType", c.serviceType); put("oilPrice", c.oilPrice); put("servicePrice", c.servicePrice)
            put("paid", c.paid); put("remaining", c.remaining); put("days", c.days); put("lastDate", c.lastDate); put("nextDate", c.nextDate)
        }
        return writableDatabase.insert("customers", null, v)
    }

    fun updatePayment(id: Long, paid: Double, remaining: Double) {
        val v = ContentValues().apply { put("paid", paid); put("remaining", remaining) }
        writableDatabase.update("customers", v, "id=?", arrayOf(id.toString()))
    }

    fun all(): List<Customer> = query(null, null)
    fun dueOnly(): List<Customer> = query("remaining > 0", null)
    fun search(s: String): List<Customer> = query("name LIKE ? OR phone LIKE ?", arrayOf("%$s%", "%$s%"))

    private fun query(selection: String?, args: Array<String>?): List<Customer> {
        val out = mutableListOf<Customer>()
        readableDatabase.query("customers", null, selection, args, null, null, "id DESC").use { cur ->
            while (cur.moveToNext()) {
                out += Customer(
                    cur.getLong(cur.getColumnIndexOrThrow("id")),
                    cur.getString(cur.getColumnIndexOrThrow("name")),
                    cur.getString(cur.getColumnIndexOrThrow("phone")) ?: "",
                    cur.getString(cur.getColumnIndexOrThrow("vehicle")) ?: "",
                    cur.getString(cur.getColumnIndexOrThrow("oilType")) ?: "",
                    cur.getString(cur.getColumnIndexOrThrow("serviceType")),
                    cur.getDouble(cur.getColumnIndexOrThrow("oilPrice")),
                    cur.getDouble(cur.getColumnIndexOrThrow("servicePrice")),
                    cur.getDouble(cur.getColumnIndexOrThrow("paid")),
                    cur.getDouble(cur.getColumnIndexOrThrow("remaining")),
                    cur.getInt(cur.getColumnIndexOrThrow("days")),
                    cur.getString(cur.getColumnIndexOrThrow("lastDate")) ?: "",
                    cur.getString(cur.getColumnIndexOrThrow("nextDate")) ?: ""
                )
            }
        }
        return out
    }

    fun addProduct(p: Product): Long {
        val v = ContentValues().apply {
            put("name", p.name); put("category", p.category); put("unit", p.unit); put("barcode", p.barcode)
            put("quantity", p.quantity); put("purchasePrice", p.purchasePrice); put("salePrice", p.salePrice)
            put("minStock", p.minStock); put("createdAt", p.createdAt)
        }
        return writableDatabase.insert("products", null, v)
    }

    fun products(): List<Product> {
        val out = mutableListOf<Product>()
        readableDatabase.query("products", null, null, null, null, null, "name COLLATE NOCASE ASC").use { c ->
            while (c.moveToNext()) {
                out += Product(
                    c.getLong(c.getColumnIndexOrThrow("id")),
                    c.getString(c.getColumnIndexOrThrow("name")),
                    c.getString(c.getColumnIndexOrThrow("category")) ?: "",
                    c.getString(c.getColumnIndexOrThrow("unit")) ?: "علبة",
                    c.getDouble(c.getColumnIndexOrThrow("quantity")),
                    c.getDouble(c.getColumnIndexOrThrow("purchasePrice")),
                    c.getDouble(c.getColumnIndexOrThrow("salePrice")),
                    c.getDouble(c.getColumnIndexOrThrow("minStock")),
                    c.getString(c.getColumnIndexOrThrow("createdAt")),
                    c.getString(c.getColumnIndexOrThrow("barcode")) ?: ""
                )
            }
        }
        return out
    }

    fun productByBarcode(code: String): Product? = products().firstOrNull { it.barcode == code }

    fun sellProduct(productId: Long, qty: Double, unitPrice: Double): Boolean {
        if (qty <= 0) return false
        val db = writableDatabase
        db.beginTransaction()
        return try {
            val q = db.rawQuery("SELECT quantity FROM products WHERE id=?", arrayOf(productId.toString()))
            val stock = if (q.moveToFirst()) q.getDouble(0) else -1.0
            q.close()
            if (stock < qty) return false
            db.update("products", ContentValues().apply { put("quantity", stock - qty) }, "id=?", arrayOf(productId.toString()))
            db.insert("sales", null, ContentValues().apply {
                put("productId", productId); put("quantity", qty); put("unitPrice", unitPrice); put("total", qty * unitPrice); put("soldAt", now())
            })
            db.setTransactionSuccessful()
            true
        } finally { db.endTransaction() }
    }

    fun addStock(productId: Long, qty: Double): Boolean {
        if (qty <= 0) return false
        writableDatabase.execSQL("UPDATE products SET quantity=quantity+? WHERE id=?", arrayOf(qty, productId))
        return true
    }

    fun salesForDay(day: String): List<SaleRow> = salesQuery("soldAt LIKE ?", arrayOf("$day%"))
    fun allSales(): List<SaleRow> = salesQuery(null, null)

    private fun salesQuery(sel: String?, args: Array<String>?): List<SaleRow> {
        val out = mutableListOf<SaleRow>()
        val sql = "SELECT s.id,s.productId,p.name,p.unit,s.quantity,s.unitPrice,s.total,s.soldAt FROM sales s JOIN products p ON p.id=s.productId" +
                (if (sel != null) " WHERE $sel" else "") + " ORDER BY s.id DESC"
        readableDatabase.rawQuery(sql, args).use { c ->
            while (c.moveToNext()) out += SaleRow(c.getLong(0), c.getLong(1), c.getString(2), c.getString(3), c.getDouble(4), c.getDouble(5), c.getDouble(6), c.getString(7))
        }
        return out
    }

    private fun now() = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())
}
