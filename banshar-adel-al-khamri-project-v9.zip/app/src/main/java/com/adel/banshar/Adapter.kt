package com.adel.banshar

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import java.util.Locale

class Adapter(private var items: List<Customer>) : BaseAdapter() {
    fun setItems(value: List<Customer>) { items = value; notifyDataSetChanged() }
    override fun getCount() = items.size
    override fun getItem(position: Int) = items[position]
    override fun getItemId(position: Int) = items[position].id
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val v = convertView ?: LayoutInflater.from(parent.context).inflate(R.layout.item_customer, parent, false)
        val c = items[position]
        v.findViewById<TextView>(R.id.name).text = c.name
        v.findViewById<TextView>(R.id.details).text = "${c.serviceType} • الإجمالي ${money(c.total())} • المدفوع ${money(c.paid)}"
        v.findViewById<TextView>(R.id.due).text = if (c.remaining > 0) "المتبقي: ${money(c.remaining)}" else "لا يوجد متبقي"
        return v
    }
    private fun money(x: Double) = String.format(Locale.US, "%.0f ريال", x)
}
