package com.adel.banshar

data class Product(
    val id: Long = 0,
    val name: String,
    val category: String,
    val unit: String,
    val quantity: Double,
    val purchasePrice: Double,
    val salePrice: Double,
    val minStock: Double,
    val createdAt: String,
    val barcode: String = ""
)

data class SaleRow(val id:Long,val productId:Long,val productName:String,val unit:String,val quantity:Double,val unitPrice:Double,val total:Double,val soldAt:String)
