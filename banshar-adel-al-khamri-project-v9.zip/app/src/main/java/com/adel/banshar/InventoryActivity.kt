package com.adel.banshar

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.zxing.integration.android.IntentIntegrator
import com.google.zxing.integration.android.IntentResult
import java.text.SimpleDateFormat
import java.util.*

class InventoryActivity : AppCompatActivity() {
    private lateinit var db: Db
    private lateinit var list: ListView
    private lateinit var summary: TextView
    private var products = emptyList<Product>()
    private var scanMode = ""
    private var productDialog: AlertDialog? = null
    private var productBarcode: EditText? = null
    private var sellSpinner: Spinner? = null
    private var stockSpinner: Spinner? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_inventory)
        db = Db(this)
        list = findViewById(R.id.productList)
        summary = findViewById(R.id.inventorySummary)
        findViewById<Button>(R.id.addProduct).setOnClickListener { addProductDialog() }
        findViewById<Button>(R.id.sellProduct).setOnClickListener { sellDialog() }
        findViewById<Button>(R.id.addStock).setOnClickListener { stockDialog() }
        findViewById<Button>(R.id.dailyReport).setOnClickListener { report(false) }
        findViewById<Button>(R.id.generalReport).setOnClickListener { report(true) }
        refresh()
    }

    override fun onResume() { super.onResume(); if (::db.isInitialized) refresh() }

    private fun refresh() {
        products = db.products()
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,
            products.map { p -> "${p.name} | ${fmt(p.quantity)} ${p.unit} | بيع: ${fmt(p.salePrice)} ريال" +
                    (if (p.barcode.isNotBlank()) " | QR: ${p.barcode}" else "") +
                    (if (p.minStock > 0 && p.quantity <= p.minStock) "  ⚠️ مخزون منخفض" else "") })
        summary.text = "الأصناف: ${products.size} | إجمالي الكمية: ${fmt(products.sumOf { it.quantity })} | قيمة البيع للمخزون: ${fmt(products.sumOf { it.quantity * it.salePrice })} ريال"
    }

    private fun addProductDialog() {
        val v = LayoutInflater.from(this).inflate(R.layout.dialog_product, null)
        val n = v.findViewById<EditText>(R.id.pName)
        val code = v.findViewById<EditText>(R.id.pBarcode)
        productBarcode = code
        v.findViewById<Button>(R.id.scanProductBarcode).setOnClickListener {
            scanMode = "product"
            startScanner("صوّر QR أو باركود المنتج")
        }
        val cat = v.findViewById<EditText>(R.id.pCategory)
        val unit = v.findViewById<EditText>(R.id.pUnit)
        val q = v.findViewById<EditText>(R.id.pQty)
        val buy = v.findViewById<EditText>(R.id.pBuy)
        val sell = v.findViewById<EditText>(R.id.pSell)
        val min = v.findViewById<EditText>(R.id.pMin)
        productDialog = AlertDialog.Builder(this).setTitle("إضافة بضاعة")
            .setView(v)
            .setPositiveButton("حفظ") { _, _ ->
                if (n.text.toString().trim().isEmpty()) {
                    Toast.makeText(this, "اكتب اسم المنتج", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                db.addProduct(Product(name = n.text.toString().trim(), category = cat.text.toString().trim(),
                    unit = unit.text.toString().trim().ifEmpty { "علبة" }, quantity = num(q),
                    purchasePrice = num(buy), salePrice = num(sell), minStock = num(min),
                    createdAt = todayTime(), barcode = code.text.toString().trim()))
                refresh()
            }.setNegativeButton("إلغاء", null).create()
        productDialog?.show()
    }

    private fun sellDialog() {
        if (products.isEmpty()) { Toast.makeText(this, "أضف البضاعة أولاً", Toast.LENGTH_SHORT).show(); return }
        val v = LayoutInflater.from(this).inflate(R.layout.dialog_sell, null)
        val sp = v.findViewById<Spinner>(R.id.productSpinner)
        sellSpinner = sp
        val q = v.findViewById<EditText>(R.id.sellQty)
        val price = v.findViewById<EditText>(R.id.sellPrice)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            products.map { "${it.name} — المتبقي ${fmt(it.quantity)} ${it.unit}" })
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p: AdapterView<*>?) {}
            override fun onItemSelected(p: AdapterView<*>?, view: android.view.View?, pos: Int, id: Long) {
                price.setText(products[pos].salePrice.toString())
            }
        }
        val d = AlertDialog.Builder(this).setTitle("تسجيل بيع")
            .setView(v)
            .setPositiveButton("بيع وخصم من المخزون") { _, _ ->
                val p = products[sp.selectedItemPosition]
                val ok = db.sellProduct(p.id, num(q), num(price))
                Toast.makeText(this, if (ok) "تم البيع وخصم ${fmt(num(q))} ${p.unit} من المخزون" else "تعذر البيع: الكمية غير متوفرة", Toast.LENGTH_LONG).show()
                refresh()
            }.setNegativeButton("إلغاء", null).create()
        v.findViewById<Button>(R.id.scanSellBarcode).setOnClickListener {
            scanMode = "sell"
            startScanner("صوّر QR أو باركود المنتج المراد بيعه")
        }
        d.show()
    }

    private fun stockDialog() {
        if (products.isEmpty()) { Toast.makeText(this, "أضف البضاعة أولاً", Toast.LENGTH_SHORT).show(); return }
        val v = LayoutInflater.from(this).inflate(R.layout.dialog_stock, null)
        val sp = v.findViewById<Spinner>(R.id.stockSpinner)
        stockSpinner = sp
        val q = v.findViewById<EditText>(R.id.stockQty)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, products.map { it.name })
        val d = AlertDialog.Builder(this).setTitle("إضافة كمية للمخزون").setView(v)
            .setPositiveButton("إضافة") { _, _ ->
                val p = products[sp.selectedItemPosition]
                db.addStock(p.id, num(q)); refresh()
            }.setNegativeButton("إلغاء", null).create()
        v.findViewById<Button>(R.id.scanStockBarcode).setOnClickListener {
            scanMode = "stock"
            startScanner("صوّر QR أو باركود المنتج لإضافة الكمية")
        }
        d.show()
    }

    private fun startScanner(prompt: String) {
        IntentIntegrator(this).setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES)
            .setPrompt(prompt).setBeepEnabled(true).setOrientationLocked(false).initiateScan()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        val result: IntentResult? = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
        if (result != null) {
            if (!result.contents.isNullOrBlank()) handleScan(result.contents.trim())
            else Toast.makeText(this, "تم إلغاء المسح", Toast.LENGTH_SHORT).show()
            scanMode = ""
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    private fun handleScan(code: String) {
        if (scanMode == "product") {
            productBarcode?.setText(code)
            Toast.makeText(this, "تم قراءة الكود: $code", Toast.LENGTH_SHORT).show()
            return
        }
        val p = db.productByBarcode(code)
        if (p == null) {
            Toast.makeText(this, "لا يوجد منتج مسجل بهذا الكود. أضفه أولاً مع حفظ QR/الباركود.", Toast.LENGTH_LONG).show()
            return
        }
        products = db.products()
        val pos = products.indexOfFirst { it.id == p.id }
        if (pos >= 0) {
            when (scanMode) {
                "sell" -> sellSpinner?.setSelection(pos)
                "stock" -> stockSpinner?.setSelection(pos)
            }
            Toast.makeText(this, "تم اختيار: ${p.name}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun report(general: Boolean) {
        val rows = if (general) db.allSales() else db.salesForDay(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()))
        val title = if (general) "تقرير المبيعات العام" else "مبيعات اليوم"
        val text = buildString {
            if (rows.isEmpty()) append("لا توجد مبيعات") else {
                rows.groupBy { it.productId }.values.forEach { r ->
                    val x = r.first()
                    append("${x.productName}: ${fmt(r.sumOf { it.quantity })} ${x.unit} | ${fmt(r.sumOf { it.total })} ريال\n")
                }
                append("\nإجمالي العمليات: ${rows.size}\nإجمالي المبيعات: ${fmt(rows.sumOf { it.total })} ريال")
            }
        }
        AlertDialog.Builder(this).setTitle(title).setMessage(text).setPositiveButton("إغلاق", null).show()
    }

    private fun num(e: EditText) = e.text.toString().toDoubleOrNull() ?: 0.0
    private fun fmt(x: Double) = String.format(Locale.US, "%.0f", x)
    private fun todayTime() = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
}
