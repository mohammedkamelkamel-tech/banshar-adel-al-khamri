package com.adel.banshar

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

class CustomerActivity : AppCompatActivity() {
    private lateinit var db: Db
    private var customerId = 0L
    private var existing: Customer? = null
    private lateinit var name: EditText; private lateinit var phone: EditText; private lateinit var vehicle: EditText; private lateinit var oilType: EditText
    private lateinit var days: EditText; private lateinit var remaining: TextView; private lateinit var oilImage: ImageView
    private var oilImagePath = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_customer); db = Db(this)
        name=findViewById(R.id.name); phone=findViewById(R.id.phone); vehicle=findViewById(R.id.vehicle); oilType=findViewById(R.id.oilType); days=findViewById(R.id.days); remaining=findViewById(R.id.remaining); oilImage=findViewById(R.id.oilImage)
        findViewById<Button>(R.id.takeOilPhoto).setOnClickListener { startActivityForResult(Intent(MediaStore.ACTION_IMAGE_CAPTURE), REQUEST_OIL_PHOTO) }
        customerId=intent.getLongExtra("id",0L)
        if(customerId>0){ existing=db.all().firstOrNull{it.id==customerId}; existing?.let{fill(it)}; findViewById<Button>(R.id.save).text="حفظ التعديلات"; findViewById<Button>(R.id.payDue).visibility=View.VISIBLE; findViewById<Button>(R.id.sms).visibility=View.VISIBLE; findViewById<Button>(R.id.whatsapp).visibility=View.VISIBLE; findViewById<Button>(R.id.payDue).setOnClickListener{payDue()}; findViewById<Button>(R.id.sms).setOnClickListener{sendSms()}; findViewById<Button>(R.id.whatsapp).setOnClickListener{whatsapp()} }
        else days.setText("30")
        findViewById<Button>(R.id.save).setOnClickListener{save()}
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.SEND_SMS), SMS_PERMISSION)
        showRemaining()
    }

    private fun save(){
        if(name.text.toString().trim().isEmpty()){name.error="اكتب اسم العميل";return}
        val daysValue=(days.text.toString().toIntOrNull()?:30).coerceAtLeast(1)
        val last=existing?.lastDate?.ifBlank{today()}?:today(); val next=dateAfter(last,daysValue)
        val c=Customer(id=customerId,name=name.text.toString().trim(),phone=phone.text.toString().trim(),vehicle=vehicle.text.toString().trim(),oilType=oilType.text.toString().trim(),oilImagePath=oilImagePath,remaining=existing?.remaining?:0.0,paid=existing?.paid?:0.0,days=daysValue,lastDate=last,nextDate=next)
        val id=if(existing==null) db.insert(c) else {db.updateCustomer(c);c.id}
        val saved=if(existing==null) c.copy(id=id) else c
        ReminderScheduler.schedule(this,saved)
        Toast.makeText(this,"تم الحفظ",Toast.LENGTH_SHORT).show();finish()
    }
    private fun fill(c:Customer){name.setText(c.name);phone.setText(c.phone);vehicle.setText(c.vehicle);oilType.setText(c.oilType);days.setText(c.days.toString());oilImagePath=c.oilImagePath;showOilImage();showRemaining()}
    private fun showRemaining(){remaining.text=if((existing?.remaining?:0.0)>0)"المستحق على العميل: ${money(existing!!.remaining)} ريال" else "لا يوجد مبلغ مستحق على العميل"}
    private fun payDue(){val c=existing?:return;if(c.remaining<=0){Toast.makeText(this,"لا يوجد مبلغ متبقي",Toast.LENGTH_SHORT).show();return};val input=EditText(this).apply{hint="مبلغ السداد";inputType=2 or 8192};val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,8,24,8);addView(input)};val save=Button(this).apply{text="حفظ السداد"};box.addView(save);val dialog=AlertDialog.Builder(this).setTitle("تسجيل سداد").setView(box).setNegativeButton("إلغاء",null).create();save.setOnClickListener{val a=input.text.toString().toDoubleOrNull()?:0.0;if(a<=0){input.error="أدخل مبلغًا صحيحًا";return@setOnClickListener};val p=minOf(c.remaining,a);db.updatePayment(c.id,maxOf(c.paid+p,0.0),maxOf(c.remaining-p,0.0));dialog.dismiss();Toast.makeText(this,"تم حفظ السداد",Toast.LENGTH_SHORT).show();finish()};dialog.show()}
    private fun reminderMessage()="مرحباً ${name.text}، حان موعد تغيير الزيت لسيارتك. بنشر عادل الخامري - فروة. نسعد بخدمتك."
    private fun sendSms(){val n=phone.text.toString().trim();if(n.isEmpty()){phone.error="أدخل رقم الهاتف";return};if(ActivityCompat.checkSelfPermission(this,Manifest.permission.SEND_SMS)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.SEND_SMS),SMS_PERMISSION);return};try{android.telephony.SmsManager.getDefault().sendTextMessage(n,null,reminderMessage(),null,null);Toast.makeText(this,"تم إرسال الرسالة",Toast.LENGTH_SHORT).show()}catch(e:Exception){startActivity(Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:$n")).putExtra("sms_body",reminderMessage()))}}
    private fun whatsapp(){val n=phone.text.toString().replace("+","").replace(" ","");if(n.isEmpty())return;val msg=Uri.encode(reminderMessage());try{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/$n?text=$msg")))}catch(_:Exception){Toast.makeText(this,"واتساب غير مثبت",Toast.LENGTH_SHORT).show()}}
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode==REQUEST_OIL_PHOTO&&resultCode==Activity.RESULT_OK){val b=data?.extras?.get("data") as? Bitmap;if(b!=null){oilImagePath=saveBitmap(b,"oil_${System.currentTimeMillis()}.jpg");showOilImage();Toast.makeText(this,"تم حفظ صورة نوع الزيت",Toast.LENGTH_SHORT).show()}}}
    private fun showOilImage(){if(oilImagePath.isBlank()){oilImage.visibility=View.GONE;return};val b=android.graphics.BitmapFactory.decodeFile(oilImagePath);oilImage.setImageBitmap(b);oilImage.visibility=if(b!=null)View.VISIBLE else View.GONE}
    private fun saveBitmap(bitmap:Bitmap,fileName:String):String{val f=File(filesDir,fileName);FileOutputStream(f).use{bitmap.compress(Bitmap.CompressFormat.JPEG,88,it)};return f.absolutePath}
    private fun today()=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
    private fun dateAfter(date:String,days:Int):String{val d=SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(date)?:Date();return SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date(d.time+days*86_400_000L))}
    private fun money(x:Double)=String.format(Locale.US,"%.0f",x)
    companion object{const val REQUEST_OIL_PHOTO=701;const val SMS_PERMISSION=900}
}
