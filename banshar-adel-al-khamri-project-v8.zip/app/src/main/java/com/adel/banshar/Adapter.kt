package com.adel.banshar

import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.*

class Adapter(private var items: List<Customer>) : BaseAdapter() {
    fun setItems(value: List<Customer>){items=value;notifyDataSetChanged()}
    override fun getCount()=items.size; override fun getItem(position:Int)=items[position]; override fun getItemId(position:Int)=items[position].id
    override fun getView(position:Int,convertView:View?,parent:ViewGroup):View{val v=convertView?:LayoutInflater.from(parent.context).inflate(R.layout.item_customer,parent,false);val c=items[position];v.findViewById<TextView>(R.id.name).text=c.name;v.findViewById<TextView>(R.id.details).text="${c.vehicle.ifBlank{"السيارة غير محددة"}} • الزيت: ${c.oilType.ifBlank{"غير محدد"}}";v.findViewById<TextView>(R.id.due).text=if(c.remaining>0)"المستحق: ${money(c.remaining)} ريال" else "لا يوجد مستحق";v.findViewById<TextView>(R.id.nextService).text=remainingText(c.nextDate);val image=v.findViewById<ImageView>(R.id.oilImage);if(c.oilImagePath.isNotBlank()){val b=BitmapFactory.decodeFile(c.oilImagePath);image.setImageBitmap(b);image.visibility=if(b!=null)View.VISIBLE else View.GONE}else image.visibility=View.GONE;v.findViewById<Button>(R.id.editCustomer).setOnClickListener{parent.context.startActivity(android.content.Intent(parent.context,CustomerActivity::class.java).putExtra("id",c.id))};return v}
    private fun money(x:Double)=String.format(Locale.US,"%.0f",x)
    private fun remainingText(next:String):String{if(next.isBlank())return "موعد الزيت: غير محدد";return try{val target=SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(next)?:return "موعد الزيت: $next";val today=SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date()))?:Date();val days=((target.time-today.time)/86_400_000L).toInt();when{days>1->"متبقي على تغيير الزيت: $days يوم";days==1->"متبقي على تغيير الزيت: يوم واحد";days==0->"موعد تغيير الزيت: اليوم";days==-1->"موعد تغيير الزيت: متأخر يوم واحد";else->"موعد تغيير الزيت: متأخر ${-days} يوم"}}catch(_:Exception){"موعد الزيت: $next"}}
}
