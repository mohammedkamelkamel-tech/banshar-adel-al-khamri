package com.adel.banshar

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var db: Db
    private lateinit var adapter: Adapter
    private lateinit var list: ListView
    private lateinit var summary: TextView
    private var showingDue = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        db = Db(this)
        list = findViewById(R.id.listCustomers)
        summary = findViewById(R.id.tvSummary)
        adapter = Adapter(emptyList())
        list.adapter = adapter
        findViewById<Button>(R.id.btnAdd).setOnClickListener { startActivity(Intent(this, CustomerActivity::class.java)) }
        findViewById<Button>(R.id.btnDue).setOnClickListener { showingDue = true; findViewById<EditText>(R.id.search).setText(""); showList(db.dueOnly()) }
        findViewById<Button>(R.id.btnAll).setOnClickListener { showingDue = false; showList(db.all()) }
        findViewById<Button>(R.id.btnInventory).setOnClickListener { startActivity(Intent(this, InventoryActivity::class.java)) }
        list.setOnItemClickListener { _, _, position, _ ->
            val c = adapter.getItem(position)
            startActivity(Intent(this, CustomerActivity::class.java).putExtra("id", c.id))
        }
        findViewById<EditText>(R.id.search).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, before: Int, count: Int) {
                val text=s?.toString().orEmpty()
                showList(if (text.isBlank()) { if(showingDue) db.dueOnly() else db.all() } else db.search(text).let { if(showingDue) it.filter { c -> c.remaining > 0 } else it })
            }
            override fun afterTextChanged(s: Editable?) {}
        })
        showList(db.all())
    }

    override fun onResume() { super.onResume(); if (::db.isInitialized) { val q=findViewById<EditText>(R.id.search).text.toString(); val items=if(q.isBlank()) { if(showingDue) db.dueOnly() else db.all() } else db.search(q).let { if(showingDue) it.filter { c -> c.remaining > 0 } else it }; showList(items) } }

    private fun showList(items: List<Customer>) {
        adapter.setItems(items)
        val due = items.sumOf { it.remaining }
        val label=if(showingDue) "المستحقات" else "كل العملاء"
        summary.text = "$label | عدد العملاء: ${items.size} | إجمالي المستحقات: ${String.format(Locale.US, "%.0f", due)} ريال"
    }
}
