package com.adel.banshar

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class Db(context: Context) : SQLiteOpenHelper(context, "banshar.db", null, 6) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE customers (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,vehicle TEXT,oilType TEXT,oilImagePath TEXT DEFAULT '',serviceType TEXT NOT NULL DEFAULT '',oilPrice REAL DEFAULT 0,servicePrice REAL DEFAULT 0,paid REAL DEFAULT 0,remaining REAL DEFAULT 0,days INTEGER DEFAULT 30,lastDate TEXT,nextDate TEXT)""")
        createInventoryTables(db)
        createFinanceTables(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) createInventoryTables(db)
        if (oldVersion >= 2 && oldVersion < 3) db.execSQL("ALTER TABLE products ADD COLUMN barcode TEXT DEFAULT ''")
        if (oldVersion < 4) {
            try { db.execSQL("ALTER TABLE customers ADD COLUMN oilImagePath TEXT DEFAULT ''") } catch (_: Exception) {}
            try { db.execSQL("ALTER TABLE products ADD COLUMN imagePath TEXT DEFAULT ''") } catch (_: Exception) {}
        }
        if (oldVersion < 5) {
            try { db.execSQL("ALTER TABLE sales ADD COLUMN customerId INTEGER DEFAULT 0") } catch (_: Exception) {}
            try { db.execSQL("ALTER TABLE sales ADD COLUMN paid REAL DEFAULT 0") } catch (_: Exception) {}
            try { db.execSQL("ALTER TABLE sales ADD COLUMN remaining REAL DEFAULT 0") } catch (_: Exception) {}
            db.execSQL("""CREATE TABLE IF NOT EXISTS service_sales (id INTEGER PRIMARY KEY AUTOINCREMENT,customerId INTEGER DEFAULT 0,serviceType TEXT NOT NULL,customerName TEXT,quantity REAL DEFAULT 1,unitPrice REAL NOT NULL,total REAL NOT NULL,paid REAL DEFAULT 0,remaining REAL DEFAULT 0,soldAt TEXT NOT NULL)""")
        }
        if (oldVersion < 6) createFinanceTables(db)
    }

    private fun createInventoryTables(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,category TEXT,unit TEXT DEFAULT 'علبة',barcode TEXT DEFAULT '',quantity REAL DEFAULT 0,purchasePrice REAL DEFAULT 0,salePrice REAL DEFAULT 0,minStock REAL DEFAULT 0,createdAt TEXT NOT NULL,imagePath TEXT DEFAULT '')""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS sales (id INTEGER PRIMARY KEY AUTOINCREMENT,productId INTEGER NOT NULL,quantity REAL NOT NULL,unitPrice REAL NOT NULL,total REAL NOT NULL,soldAt TEXT NOT NULL,customerId INTEGER DEFAULT 0,paid REAL DEFAULT 0,remaining REAL DEFAULT 0)""")
    }

    private fun createFinanceTables(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE IF NOT EXISTS expenses (id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,amount REAL NOT NULL,note TEXT DEFAULT '',spentAt TEXT NOT NULL)""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS service_sales (id INTEGER PRIMARY KEY AUTOINCREMENT,customerId INTEGER DEFAULT 0,serviceType TEXT NOT NULL,customerName TEXT,quantity REAL DEFAULT 1,unitPrice REAL NOT NULL,total REAL NOT NULL,paid REAL DEFAULT 0,remaining REAL DEFAULT 0,soldAt TEXT NOT NULL)""")
    }

    fun insert(c: Customer): Long = saveCustomer(c, null)
    fun updateCustomer(c: Customer): Boolean = saveCustomer(c, c.id) > 0

    private fun saveCustomer(c: Customer, id: Long?): Long {
        val v = ContentValues().apply {
            put("name", c.name); put("phone", c.phone); put("vehicle", c.vehicle); put("oilType", c.oilType); put("oilImagePath", c.oilImagePath)
            put("serviceType", ""); put("oilPrice", 0.0); put("servicePrice", 0.0); put("paid", c.paid); put("remaining", c.remaining)
            put("days", c.days); put("lastDate", c.lastDate); put("nextDate", c.nextDate)
        }
        return if (id == null) writableDatabase.insert("customers", null, v) else writableDatabase.update("customers", v, "id=?", arrayOf(id.toString())).toLong()
    }

    fun updatePayment(id: Long, paid: Double, remaining: Double) {
        writableDatabase.update("customers", ContentValues().apply { put("paid", paid); put("remaining", remaining) }, "id=?", arrayOf(id.toString()))
    }

    fun addCustomerDebt(customerId: Long, amount: Double) {
        if (customerId <= 0 || amount <= 0) return
        writableDatabase.execSQL("UPDATE customers SET remaining=remaining+? WHERE id=?", arrayOf(amount, customerId))
    }

    fun all(): List<Customer> = query(null, null)
    fun dueOnly(): List<Customer> = query("remaining > 0", null)
    fun search(s: String): List<Customer> = query("name LIKE ? OR phone LIKE ?", arrayOf("%$s%", "%$s%"))

    private fun query(selection: String?, args: Array<String>?): List<Customer> {
        val out = mutableListOf<Customer>()
        readableDatabase.query("customers", null, selection, args, null, null, "id DESC").use { cur ->
            while (cur.moveToNext()) out += Customer(
                cur.getLong(cur.getColumnIndexOrThrow("id")),
                cur.getString(cur.getColumnIndexOrThrow("name")),
                cur.getString(cur.getColumnIndexOrThrow("phone")) ?: "",
                cur.getString(cur.getColumnIndexOrThrow("vehicle")) ?: "",
                cur.getString(cur.getColumnIndexOrThrow("oilType")) ?: "",
                cur.getString(cur.getColumnIndexOrThrow("oilImagePath")) ?: "",
                cur.getString(cur.getColumnIndexOrThrow("serviceType")) ?: "",
                cur.getDouble(cur.getColumnIndexOrThrow("oilPrice")), cur.getDouble(cur.getColumnIndexOrThrow("servicePrice")),
                cur.getDouble(cur.getColumnIndexOrThrow("paid")), cur.getDouble(cur.getColumnIndexOrThrow("remaining")),
                cur.getInt(cur.getColumnIndexOrThrow("days")), cur.getString(cur.getColumnIndexOrThrow("lastDate")) ?: "", cur.getString(cur.getColumnIndexOrThrow("nextDate")) ?: ""
            )
        }
        return out
    }

    fun products(): List<Product> {
        val out = mutableListOf<Product>()
        readableDatabase.query("products", null, null, null, null, null, "name COLLATE NOCASE ASC").use { c ->
            while (c.moveToNext()) out += Product(c.getLong(c.getColumnIndexOrThrow("id")), c.getString(c.getColumnIndexOrThrow("name")), c.getString(c.getColumnIndexOrThrow("category")) ?: "", c.getString(c.getColumnIndexOrThrow("unit")) ?: "علبة", c.getDouble(c.getColumnIndexOrThrow("quantity")), c.getDouble(c.getColumnIndexOrThrow("purchasePrice")), c.getDouble(c.getColumnIndexOrThrow("salePrice")), c.getDouble(c.getColumnIndexOrThrow("minStock")), c.getString(c.getColumnIndexOrThrow("createdAt")), c.getString(c.getColumnIndexOrThrow("barcode")) ?: "", c.getString(c.getColumnIndexOrThrow("imagePath")) ?: "")
        }
        return out
    }
    fun productByBarcode(code: String): Product? = products().firstOrNull { it.barcode == code }

    fun addProduct(p: Product): Long = writableDatabase.insert("products", null, ContentValues().apply { put("name", p.name); put("category", p.category); put("unit", p.unit); put("barcode", p.barcode); put("quantity", p.quantity); put("purchasePrice", p.purchasePrice); put("salePrice", p.salePrice); put("minStock", p.minStock); put("createdAt", p.createdAt); put("imagePath", p.imagePath) })
    fun updateProduct(p: Product): Boolean = writableDatabase.update("products", ContentValues().apply { put("name", p.name); put("category", p.category); put("unit", p.unit); put("barcode", p.barcode); put("quantity", p.quantity); put("purchasePrice", p.purchasePrice); put("salePrice", p.salePrice); put("minStock", p.minStock); put("createdAt", p.createdAt); put("imagePath", p.imagePath) }, "id=?", arrayOf(p.id.toString())) > 0

    fun sellProduct(productId: Long, qty: Double, unitPrice: Double, customerId: Long, paid: Double): Boolean {
        if (qty <= 0 || unitPrice < 0) return false
        val db = writableDatabase; db.beginTransaction()
        return try {
            val q = db.rawQuery("SELECT quantity FROM products WHERE id=?", arrayOf(productId.toString())); val stock = if (q.moveToFirst()) q.getDouble(0) else -1.0; q.close()
            if (stock < qty) return false
            val total = qty * unitPrice; val rem = maxOf(total - paid, 0.0)
            db.update("products", ContentValues().apply { put("quantity", stock - qty) }, "id=?", arrayOf(productId.toString()))
            db.insert("sales", null, ContentValues().apply { put("productId", productId); put("quantity", qty); put("unitPrice", unitPrice); put("total", total); put("soldAt", now()); put("customerId", customerId); put("paid", paid); put("remaining", rem) })
            if (customerId > 0 && rem > 0) db.execSQL("UPDATE customers SET remaining=remaining+? WHERE id=?", arrayOf(rem, customerId))
            db.setTransactionSuccessful(); true
        } finally { db.endTransaction() }
    }

    fun addServiceSale(customerId: Long, customerName: String, serviceType: String, price: Double, paid: Double): Boolean {
        if (serviceType.isBlank() || price < 0) return false
        val total = price; val rem = maxOf(total - paid, 0.0); val db = writableDatabase; db.beginTransaction()
        return try {
            db.insert("service_sales", null, ContentValues().apply { put("customerId", customerId); put("customerName", customerName); put("serviceType", serviceType); put("quantity", 1); put("unitPrice", price); put("total", total); put("paid", paid); put("remaining", rem); put("soldAt", now()) })
            if (customerId > 0 && rem > 0) db.execSQL("UPDATE customers SET remaining=remaining+? WHERE id=?", arrayOf(rem, customerId))
            db.setTransactionSuccessful(); true
        } finally { db.endTransaction() }
    }

    fun addStock(productId: Long, qty: Double): Boolean { if (qty <= 0) return false; writableDatabase.execSQL("UPDATE products SET quantity=quantity+? WHERE id=?", arrayOf(qty, productId)); return true }

    fun salesForDay(day: String): List<SaleRow> = salesQuery("soldAt LIKE ?", arrayOf("$day%"))
    fun allSales(): List<SaleRow> = salesQuery(null, null)
    private fun salesQuery(sel: String?, args: Array<String>?): List<SaleRow> {
        val out = mutableListOf<SaleRow>()
        val psql = "SELECT s.id,s.productId,p.name,p.unit,s.quantity,s.unitPrice,s.total,s.soldAt,COALESCE(p.imagePath,''),COALESCE(c.name,''),'' AS serviceType,s.paid,s.remaining FROM sales s JOIN products p ON p.id=s.productId LEFT JOIN customers c ON c.id=s.customerId" + if (sel != null) " WHERE $sel" else ""
        readableDatabase.rawQuery(psql + " ORDER BY s.id DESC", args).use { c -> while (c.moveToNext()) out += SaleRow(c.getLong(0),c.getLong(1),c.getString(2),c.getString(3),c.getDouble(4),c.getDouble(5),c.getDouble(6),c.getString(7),c.getString(8) ?: "",c.getString(9) ?: "",c.getString(10) ?: "",c.getDouble(11),c.getDouble(12)) }
        val sargs = args
        val serviceSel = if (sel == null) null else sel.replace("soldAt", "soldAt")
        val sql2 = "SELECT id,customerId,customerName,serviceType,quantity,unitPrice,total,soldAt,paid,remaining FROM service_sales" + if (serviceSel != null) " WHERE $serviceSel" else ""
        readableDatabase.rawQuery(sql2, sargs).use { c -> while (c.moveToNext()) out += SaleRow(1_000_000_000L+c.getLong(0),0,c.getString(3),"خدمة",c.getDouble(4),c.getDouble(5),c.getDouble(6),c.getString(7),"",c.getString(2) ?: "",c.getString(3),c.getDouble(8),c.getDouble(9)) }
        return out.sortedByDescending { it.soldAt }
    }

    fun addExpense(title: String, amount: Double, note: String): Long = writableDatabase.insert("expenses", null, ContentValues().apply { put("title", title); put("amount", amount); put("note", note); put("spentAt", now()) })
    fun updateExpense(id: Long, title: String, amount: Double, note: String): Boolean = writableDatabase.update("expenses", ContentValues().apply { put("title", title); put("amount", amount); put("note", note) }, "id=?", arrayOf(id.toString())) > 0
    fun expenses(): List<ExpenseRow> { val out=mutableListOf<ExpenseRow>(); readableDatabase.query("expenses",null,null,null,null,null,"id DESC").use{c->while(c.moveToNext())out+=ExpenseRow(c.getLong(0),c.getString(1),c.getDouble(2),c.getString(3) ?: "",c.getString(4))};return out }

    private fun now() = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())
}
