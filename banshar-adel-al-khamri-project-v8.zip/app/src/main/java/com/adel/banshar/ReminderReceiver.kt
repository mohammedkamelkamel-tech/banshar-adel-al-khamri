package com.adel.banshar

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.SmsManager
import android.widget.Toast

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra("customerId", 0L)
        if (id <= 0) return
        val c = Db(context).all().firstOrNull { it.id == id } ?: return
        if (c.phone.isBlank()) return
        val msg = "مرحباً ${c.name}، حان موعد تغيير الزيت لسيارتك. بنشر عادل الخامري - فروة. نسعد بخدمتك."
        try { SmsManager.getDefault().sendTextMessage(c.phone, null, msg, null, null) } catch (_: Exception) { Toast.makeText(context, "تعذر إرسال تذكير ${c.name}", Toast.LENGTH_SHORT).show() }
    }
}
