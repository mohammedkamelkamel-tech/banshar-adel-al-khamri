package com.adel.banshar

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class Db(context: Context) : SQLiteOpenHelper(context, "banshar.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE customers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                phone TEXT,
                vehicle TEXT,
                oilType TEXT,
                serviceType TEXT NOT NULL,
                oilPrice REAL DEFAULT 0,
                servicePrice REAL DEFAULT 0,
                paid REAL DEFAULT 0,
                remaining REAL DEFAULT 0,
                days INTEGER DEFAULT 30,
                lastDate TEXT,
                nextDate TEXT
            )
        """.trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun insert(c: Customer): Long {
        val v = ContentValues().apply {
            put("name", c.name); put("phone", c.phone); put("vehicle", c.vehicle); put("oilType", c.oilType)
            put("serviceType", c.serviceType); put("oilPrice", c.oilPrice); put("servicePrice", c.servicePrice)
            put("paid", c.paid); put("remaining", c.remaining); put("days", c.days)
            put("lastDate", c.lastDate); put("nextDate", c.nextDate)
        }
        return writableDatabase.insert("customers", null, v)
    }

    fun updatePayment(id: Long, paid: Double, remaining: Double) {
        val v = ContentValues().apply { put("paid", paid); put("remaining", remaining) }
        writableDatabase.update("customers", v, "id=?", arrayOf(id.toString()))
    }

    fun all(): List<Customer> = query(null, null)

    fun dueOnly(): List<Customer> = query("remaining > 0", null)

    fun search(s: String): List<Customer> = query("name LIKE ? OR phone LIKE ?", arrayOf("%$s%", "%$s%"))

    private fun query(selection: String?, args: Array<String>?): List<Customer> {
        val out = mutableListOf<Customer>()
        readableDatabase.query("customers", null, selection, args, null, null, "id DESC").use { cur ->
            while (cur.moveToNext()) {
                out += Customer(
                    cur.getLong(cur.getColumnIndexOrThrow("id")),
                    cur.getString(cur.getColumnIndexOrThrow("name")),
                    cur.getString(cur.getColumnIndexOrThrow("phone")) ?: "",
                    cur.getString(cur.getColumnIndexOrThrow("vehicle")) ?: "",
                    cur.getString(cur.getColumnIndexOrThrow("oilType")) ?: "",
                    cur.getString(cur.getColumnIndexOrThrow("serviceType")),
                    cur.getDouble(cur.getColumnIndexOrThrow("oilPrice")),
                    cur.getDouble(cur.getColumnIndexOrThrow("servicePrice")),
                    cur.getDouble(cur.getColumnIndexOrThrow("paid")),
                    cur.getDouble(cur.getColumnIndexOrThrow("remaining")),
                    cur.getInt(cur.getColumnIndexOrThrow("days")),
                    cur.getString(cur.getColumnIndexOrThrow("lastDate")) ?: "",
                    cur.getString(cur.getColumnIndexOrThrow("nextDate")) ?: ""
                )
            }
        }
        return out
    }
}
