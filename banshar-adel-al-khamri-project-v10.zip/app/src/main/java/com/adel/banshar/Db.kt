package com.adel.banshar

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.*

class Db(context: Context) : SQLiteOpenHelper(context, "banshar.db", null, 6) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE customers (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,vehicle TEXT,oilType TEXT,serviceType TEXT DEFAULT '',oilPrice REAL DEFAULT 0,servicePrice REAL DEFAULT 0,paid REAL DEFAULT 0,remaining REAL DEFAULT 0,days INTEGER DEFAULT 30,lastDate TEXT,nextDate TEXT)")
        createInventoryTables(db)
    }
    override fun onUpgrade(db: SQLiteDatabase, old:Int, new:Int) {
        if (old < 2) createInventoryTables(db)
        if (old < 3) try { db.execSQL("ALTER TABLE products ADD COLUMN barcode TEXT DEFAULT ''") } catch(_:Exception){}
        if (old < 4) {
            try { db.execSQL("ALTER TABLE sales ADD COLUMN customerId INTEGER DEFAULT 0") } catch(_:Exception){}
            try { db.execSQL("ALTER TABLE sales ADD COLUMN paid REAL DEFAULT 0") } catch(_:Exception){}
            try { db.execSQL("ALTER TABLE sales ADD COLUMN remaining REAL DEFAULT 0") } catch(_:Exception){}
        }
        if (old < 5) db.execSQL("CREATE TABLE IF NOT EXISTS service_sales (id INTEGER PRIMARY KEY AUTOINCREMENT,customerId INTEGER DEFAULT 0,customerName TEXT,serviceType TEXT,quantity REAL DEFAULT 1,unitPrice REAL,total REAL,paid REAL DEFAULT 0,remaining REAL DEFAULT 0,soldAt TEXT NOT NULL)")
        if (old < 6) db.execSQL("CREATE TABLE IF NOT EXISTS expenses (id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,amount REAL NOT NULL,note TEXT,spentAt TEXT NOT NULL)")
    }
    private fun createInventoryTables(db:SQLiteDatabase){
        db.execSQL("CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,category TEXT,unit TEXT DEFAULT 'علبة',barcode TEXT DEFAULT '',quantity REAL DEFAULT 0,purchasePrice REAL DEFAULT 0,salePrice REAL DEFAULT 0,minStock REAL DEFAULT 0,createdAt TEXT NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS sales (id INTEGER PRIMARY KEY AUTOINCREMENT,productId INTEGER NOT NULL,quantity REAL NOT NULL,unitPrice REAL NOT NULL,total REAL NOT NULL,soldAt TEXT NOT NULL,customerId INTEGER DEFAULT 0,paid REAL DEFAULT 0,remaining REAL DEFAULT 0)")
        db.execSQL("CREATE TABLE IF NOT EXISTS service_sales (id INTEGER PRIMARY KEY AUTOINCREMENT,customerId INTEGER DEFAULT 0,customerName TEXT,serviceType TEXT,quantity REAL DEFAULT 1,unitPrice REAL,total REAL,paid REAL DEFAULT 0,remaining REAL DEFAULT 0,soldAt TEXT NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS expenses (id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,amount REAL NOT NULL,note TEXT,spentAt TEXT NOT NULL)")
    }
    private fun now()=SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(Date())
    fun insert(c:Customer):Long= writableDatabase.insert("customers",null,ContentValues().apply{put("name",c.name);put("phone",c.phone);put("vehicle",c.vehicle);put("oilType",c.oilType);put("serviceType","");put("days",c.days);put("lastDate",c.lastDate);put("nextDate",c.nextDate)})
    fun updateCustomer(c:Customer){writableDatabase.update("customers",ContentValues().apply{put("name",c.name);put("phone",c.phone);put("vehicle",c.vehicle);put("oilType",c.oilType);put("days",c.days);put("lastDate",c.lastDate);put("nextDate",c.nextDate)},"id=?",arrayOf(c.id.toString()))}
    fun updatePayment(id:Long,amount:Double){writableDatabase.execSQL("UPDATE customers SET paid=paid+?, remaining=MAX(remaining-?,0) WHERE id=?",arrayOf(amount,amount,id))}
    fun all()=query(null,null)
    fun dueOnly()=query("remaining>0",null)
    fun search(s:String)=query("name LIKE ? OR phone LIKE ? OR vehicle LIKE ?",arrayOf("%$s%","%$s%","%$s%"))
    private fun query(sel:String?,args:Array<String>?):List<Customer>{val out=mutableListOf<Customer>();readableDatabase.query("customers",null,sel,args,null,null,"id DESC").use{c->while(c.moveToNext())out+=Customer(c.getLong(c.getColumnIndexOrThrow("id")),c.getString(c.getColumnIndexOrThrow("name")),c.getString(c.getColumnIndexOrThrow("phone")) ?:"",c.getString(c.getColumnIndexOrThrow("vehicle"))?:"",c.getString(c.getColumnIndexOrThrow("oilType"))?:"",c.getString(c.getColumnIndexOrThrow("serviceType"))?:"",c.getDouble(c.getColumnIndexOrThrow("oilPrice")),c.getDouble(c.getColumnIndexOrThrow("servicePrice")),c.getDouble(c.getColumnIndexOrThrow("paid")),c.getDouble(c.getColumnIndexOrThrow("remaining")),c.getInt(c.getColumnIndexOrThrow("days")),c.getString(c.getColumnIndexOrThrow("lastDate"))?:"",c.getString(c.getColumnIndexOrThrow("nextDate"))?:"")};return out}
    fun addProduct(p:Product)=writableDatabase.insert("products",null,ContentValues().apply{put("name",p.name);put("category",p.category);put("unit",p.unit);put("barcode",p.barcode);put("quantity",p.quantity);put("purchasePrice",p.purchasePrice);put("salePrice",p.salePrice);put("minStock",p.minStock);put("createdAt",p.createdAt)})
    fun updateProduct(p:Product){writableDatabase.update("products",ContentValues().apply{put("name",p.name);put("category",p.category);put("unit",p.unit);put("barcode",p.barcode);put("quantity",p.quantity);put("purchasePrice",p.purchasePrice);put("salePrice",p.salePrice);put("minStock",p.minStock)},"id=?",arrayOf(p.id.toString()))}
    fun products():List<Product>{val o=mutableListOf<Product>();readableDatabase.query("products",null,null,null,null,null,"name COLLATE NOCASE ASC").use{c->while(c.moveToNext())o+=Product(c.getLong(c.getColumnIndexOrThrow("id")),c.getString(c.getColumnIndexOrThrow("name")),c.getString(c.getColumnIndexOrThrow("category"))?:"",c.getString(c.getColumnIndexOrThrow("unit"))?:"علبة",c.getDouble(c.getColumnIndexOrThrow("quantity")),c.getDouble(c.getColumnIndexOrThrow("purchasePrice")),c.getDouble(c.getColumnIndexOrThrow("salePrice")),c.getDouble(c.getColumnIndexOrThrow("minStock")),c.getString(c.getColumnIndexOrThrow("createdAt")),c.getString(c.getColumnIndexOrThrow("barcode"))?:"")};return o}
    fun productByBarcode(code:String)=products().firstOrNull{it.barcode==code}
    fun sellProduct(id:Long,qty:Double,price:Double,customerId:Long,paid:Double):Boolean{if(qty<=0||price<0)return false;val d=writableDatabase;d.beginTransaction();return try{val q=d.rawQuery("SELECT quantity FROM products WHERE id=?",arrayOf(id.toString()));val stock=if(q.moveToFirst())q.getDouble(0)else -1.0;q.close();if(stock<qty)return false;val total=qty*price;val rem=maxOf(total-paid,0.0);d.update("products",ContentValues().apply{put("quantity",stock-qty)},"id=?",arrayOf(id.toString()));d.insert("sales",null,ContentValues().apply{put("productId",id);put("quantity",qty);put("unitPrice",price);put("total",total);put("soldAt",now());put("customerId",customerId);put("paid",paid);put("remaining",rem)});if(customerId>0&&rem>0)d.execSQL("UPDATE customers SET remaining=remaining+? WHERE id=?",arrayOf(rem,customerId));d.setTransactionSuccessful();true}finally{d.endTransaction()}}
    fun addServiceSale(customerId:Long,customerName:String,service:String,price:Double,paid:Double):Boolean{if(service.isBlank()||price<0)return false;val total=price;val rem=maxOf(total-paid,0.0);val d=writableDatabase;d.beginTransaction();return try{d.insert("service_sales",null,ContentValues().apply{put("customerId",customerId);put("customerName",customerName);put("serviceType",service);put("quantity",1);put("unitPrice",price);put("total",total);put("paid",paid);put("remaining",rem);put("soldAt",now())});if(customerId>0&&rem>0)d.execSQL("UPDATE customers SET remaining=remaining+? WHERE id=?",arrayOf(rem,customerId));d.setTransactionSuccessful();true}finally{d.endTransaction()}}
    fun addStock(id:Long,qty:Double)=qty>0.also{if(it)writableDatabase.execSQL("UPDATE products SET quantity=quantity+? WHERE id=?",arrayOf(qty,id))}
    fun salesForDay(day:String)=salesQuery("soldAt LIKE ?",arrayOf("$day%"))
    fun allSales()=salesQuery(null,null)
    private fun salesQuery(sel:String?,args:Array<String>?):List<SaleRow>{val o=mutableListOf<SaleRow>();val q="SELECT s.id,s.productId,p.name,p.unit,s.quantity,s.unitPrice,s.total,s.paid,s.remaining,s.customerId,COALESCE(c.name,''),s.soldAt FROM sales s JOIN products p ON p.id=s.productId LEFT JOIN customers c ON c.id=s.customerId"+(if(sel!=null)" WHERE $sel" else "")+" ORDER BY s.id DESC";readableDatabase.rawQuery(q,args).use{c->while(c.moveToNext())o+=SaleRow(c.getLong(0),c.getLong(1),c.getString(2),c.getString(3),c.getDouble(4),c.getDouble(5),c.getDouble(6),c.getDouble(7),c.getDouble(8),c.getLong(9),c.getString(10),"بضاعة","",c.getString(11))};val q2="SELECT id,customerId,serviceType,quantity,unitPrice,total,paid,remaining,customerName,soldAt FROM service_sales"+(if(sel!=null)" WHERE $sel" else "")+" ORDER BY id DESC";readableDatabase.rawQuery(q2,args).use{c->while(c.moveToNext())o+=SaleRow(-c.getLong(0),0,c.getString(2),"خدمة",c.getDouble(3),c.getDouble(4),c.getDouble(5),c.getDouble(6),c.getDouble(7),c.getLong(1),c.getString(8)?:"","خدمة",c.getString(2),c.getString(9))};return o.sortedByDescending{it.soldAt}}
    fun addExpense(title:String,amount:Double,note:String){writableDatabase.insert("expenses",null,ContentValues().apply{put("title",title);put("amount",amount);put("note",note);put("spentAt",now())})}
    fun expenses():List<ExpenseRow>{val o=mutableListOf<ExpenseRow>();readableDatabase.query("expenses",null,null,null,null,null,"id DESC").use{c->while(c.moveToNext())o+=ExpenseRow(c.getLong(0),c.getString(1),c.getDouble(2),c.getString(3)?:"",c.getString(4))};return o}
}
