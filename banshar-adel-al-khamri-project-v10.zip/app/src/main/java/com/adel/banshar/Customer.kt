package com.adel.banshar

data class Customer(
    val id: Long = 0,
    val name: String,
    val phone: String,
    val vehicle: String,
    val oilType: String,
    val serviceType: String = "",
    val oilPrice: Double = 0.0,
    val servicePrice: Double = 0.0,
    val paid: Double = 0.0,
    val remaining: Double = 0.0,
    val days: Int = 30,
    val lastDate: String = "",
    val nextDate: String = ""
) { fun total() = paid + remaining }
